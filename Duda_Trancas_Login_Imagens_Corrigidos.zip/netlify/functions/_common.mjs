import {getStore} from '@netlify/blobs';
const store=()=>getStore({name:'duda-trancas',consistency:'strong'});
export async function state(){const s=await store().get('state',{type:'json'});return s||{bookings:[],blocks:[]};}
export async function save(s){await store().setJSON('state',s);}
export const reply=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
export const validDate=d=>typeof d==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(new Date(d+'T12:00:00').getTime());
export const validTime=t=>typeof t==='string'&&/^(09|10|11|12|13|14|15|16|17):00$/.test(t);
export const busy=(s,d,t)=>s.blocks.some(x=>x.date===d&&x.time===t)||s.bookings.some(x=>x.date===d&&x.time===t&&x.status!=='cancelado');
